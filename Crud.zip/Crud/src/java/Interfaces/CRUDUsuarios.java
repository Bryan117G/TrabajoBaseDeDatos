/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interfaces;

import Modelo.Usuarios;
import java.util.List;

/**
 *
 * @author bryan
 */
public interface CRUDUsuarios {
    public List listar();
    public Usuarios list(int id);
    public boolean agregarUsuarios(Usuarios per);
    public boolean editarUsuarios(Usuarios per);
    public boolean eliminarUsuarios(int id);
    
}
