/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interfaces;

import Modelo.Cargos;
import java.util.List;

/**
 *
 * @author bryan
 */
public interface CRUDCargo {
    public List listar();
    public Cargos list(int id);
    public boolean agregarCargo(Cargos per);
    public boolean editarCargo(Cargos per);
    public boolean eliminarCargo(int id);
    
}
