/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.Usuarios;
import Modelo.Cargos;
import Modelo.Localizaciones;
import Modelo.Login;
import ModeloDAO.CargosDAO;
import ModeloDAO.UsuariosDAO;
import ModeloDAO.LocalizacionesDAO;
import ModeloDAO.LoginDAO;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author bryan
 */
@WebServlet(name = "Controlador", urlPatterns = {"/Controlador"})
public class Controlador extends HttpServlet {
    LoginDAO daoLog=new LoginDAO();
    Login pLog=new Login(0," ", " ");
    int r;
    String listar = "vistas/listar.jsp";
    String agregar = "vistas/agregar.jsp";
    String editar = "vistas/editar.jsp";
    String listarCargo = "vistas/listarCargo.jsp";
    String agregarCargo = "vistas/agregarCargo.jsp";
    String editarCargo = "vistas/editarCargo.jsp";
    String listarUsuarios = "vistas/listarUsuarios.jsp";
    String agregarUsuarios = "vistas/agregarUsuarios.jsp";
    String editarUsuarios = "vistas/editarUsuarios.jsp";
    Localizaciones p = new Localizaciones(listar, Boolean.TRUE);
    LocalizacionesDAO dao = new LocalizacionesDAO();
    Cargos pCargos = new Cargos(listarCargo, Boolean.TRUE);
    CargosDAO daoCargos = new CargosDAO();
    Usuarios pUsuarios = new Usuarios(listarUsuarios, editarUsuarios, 0, 0, 0, Boolean.TRUE);
    UsuariosDAO daoUsuarios = new UsuariosDAO();

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String accion=request.getParameter("accion");
        if(accion.equals("Ingresar")){
            String nom=request.getParameter("txtnom");
            String correo=request.getParameter("txtCorreo");
            pLog.setNom(nom);
            pLog.setCorreo(correo);
            r=daoLog.validar(pLog);
            if (true) {
                request.getSession().setAttribute("nom", nom);
                request.getSession().setAttribute("correo", correo);
                request.getRequestDispatcher("Principal.jsp").forward(request, response);
            }else{
                request.getRequestDispatcher("index.jsp").forward(request, response);
            }
        }else{
            request.getRequestDispatcher("index.jsp").forward(request, response);
        } 
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Controlador</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet Controlador at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        String acceso = "";
        String action = request.getParameter("accion");
        if (action.equalsIgnoreCase("listar")) {
            acceso = listar;
        } else if (action.equalsIgnoreCase("agregar")) {
            acceso = agregar;
        } else if (action.equalsIgnoreCase("Agregar")) {
            String localizacion = request.getParameter("txtlocalizacion");
            String activo = request.getParameter("txtactivo");
            p.setLocalizacion(localizacion);
            p.setActivo(Boolean.TRUE);
            dao.agregar(p);
            acceso = listar;
        } else if (action.equalsIgnoreCase("editar")) {
            request.setAttribute("idper", request.getParameter("id"));
            acceso = editar;
        } else if (action.equalsIgnoreCase("Actualizar")) {
            int id = Integer.parseInt(request.getParameter("txtid"));
            String localizacion = request.getParameter("txtlocalizacion");
            String activo = request.getParameter("txtactivo");
            p.setId(id);
            p.setLocalizacion(localizacion);
            p.setActivo(Boolean.TRUE);
            dao.editar(p);
            acceso = listar;
        } else if (action.equalsIgnoreCase("eliminar")) {
            int id = Integer.parseInt(request.getParameter("id"));
            p.setId(id);
            dao.eliminar(id);
            acceso = listar;
        }

        if (action.equalsIgnoreCase("listarCargo")) {
            acceso = listarCargo;
        } else if (action.equalsIgnoreCase("agregarCargo")) {
            acceso = agregarCargo;
        } else if (action.equalsIgnoreCase("AgregarCargo")) {
            String cargo = request.getParameter("txtCargo");
            String activo = request.getParameter("txtactivoCargo");
            pCargos.setCargo(cargo);
            pCargos.setActivo(Boolean.TRUE);
            daoCargos.agregarCargo(pCargos);
            acceso = listarCargo;
        } else if (action.equalsIgnoreCase("editarCargo")) {
            request.setAttribute("idper", request.getParameter("id"));
            acceso = editarCargo;
        } else if (action.equalsIgnoreCase("ActualizarCargo")) {
            int id = Integer.parseInt(request.getParameter("txtidCargo"));
            String cargo = request.getParameter("txtcargo");
            String activo = request.getParameter("txtactivoCargo");
            pCargos.setId(id);
            pCargos.setCargo(cargo);
            pCargos.setActivo(Boolean.TRUE);
            daoCargos.editarCargo(pCargos);
            acceso = listarCargo;
        } else if (action.equalsIgnoreCase("eliminarCargo")) {
            int id = Integer.parseInt(request.getParameter("id"));
            pCargos.setId(id);
            daoCargos.eliminarCargo(id);
            acceso = listarCargo;

            if (action.equalsIgnoreCase("listarUsuarios")) {
                acceso = listarUsuarios;
            } else if (action.equalsIgnoreCase("agregarUsuarios")) {
                acceso = agregarUsuarios;
            } else if (action.equalsIgnoreCase("AgregarUsuarios")) {
                String nombres = request.getParameter("txtnombresUsuarios");
                String activo = request.getParameter("txtactivoUsuarios");
                pUsuarios.setNombres(nombres);
                pUsuarios.setActivo(Boolean.TRUE);
                daoUsuarios.agregarUsuarios(pUsuarios);
                acceso = listarUsuarios;
            } else if (action.equalsIgnoreCase("editarUsuarios")) {
                request.setAttribute("idper", request.getParameter("id"));
                acceso = editarUsuarios;
            } else if (action.equalsIgnoreCase("ActualizarUsuarios")) {
                int idU = Integer.parseInt(request.getParameter("txtidUsuarios"));
                String nombres = request.getParameter("txtUsuarios");
                String activo = request.getParameter("txtactivoUsuarios");
                pUsuarios.setId(id);
                pUsuarios.setNombres(nombres);
                pUsuarios.setActivo(Boolean.TRUE);
                daoUsuarios.editarUsuarios(pUsuarios);
                acceso = listarUsuarios;
            } else if (action.equalsIgnoreCase("eliminarUsuarios")) {
                int idU = Integer.parseInt(request.getParameter("id"));
                pUsuarios.setId(id);
                daoUsuarios.eliminarUsuarios(id);
                acceso = listarUsuarios;
            }
            RequestDispatcher vista = request.getRequestDispatcher(acceso);
            vista.forward(request, response);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
