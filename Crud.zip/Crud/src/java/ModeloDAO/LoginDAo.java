/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ModeloDAO;

import Config.Conexion;
import Modelo.Login;
import com.mysql.jdbc.PreparedStatement;
import java.sql.Connection;
import java.sql.ResultSet;

/**
 *
 * @author blue
 */
public class LoginDAO implements Validar {

    Connection con;
    Conexion cn = new Conexion();
    PreparedStatement ps;
    ResultSet rs;
    int r = 0;

    public int validar(Login login) {
        int r=0;
        String sql = "Select * from Login where Nombres=? and Correo=?";
        try {
            con = cn.getConnection();
            ps = (PreparedStatement) con.prepareStatement(sql);
            ps.setString(1, login.getNom());
            ps.setString(2, login.getCorreo());
            rs = ps.executeQuery();
            while (rs.next()) {
                r = r + 1;
                login.setNom(rs.getString("Nombres"));
                login.setCorreo(rs.getString("Correo"));
            }
            if (r == 1) {
                return 1;
            } else {
                return 0;
            }

        } catch (Exception e) {
            return 0;
        }
    }

}
