
package ModeloDAO;

import Config.Conexion;
import Interfaces.CRUD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import Modelo.Localizaciones;
import static java.util.Collections.list;

/**
 *
 * @author bryan
 */
public class LocalizacionesDAO implements CRUD{
    Conexion cn=new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    LocalizacionesDAO p=new LocalizacionesDAO();
    
    @Override
    public List listar() {
        ArrayList<LocalizacionesDAO>list=new ArrayList<>();
        String sql="select * from localizaciones";
        try {
            con=cn.getConnection();
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            while(rs.next()){
                LocalizacionesDAO per=new LocalizacionesDAO();
                per.setId(rs.getString("id"));
                per.setLocalizacion(rs.getString("localizacion"));
                per.setActivo(rs.getString("activo"));
                list.add(per);
            }
        } catch (Exception e) {
        }
        return list;
    }

    @Override
    public Localizaciones list(int id) {
        String sql="select * from localizaciones where id="+id;
        try {
            con=cn.getConnection();
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            while(rs.next()){
                p.setId(rs.getString("id"));
                p.setLocalizacion(rs.getString("localizacion"));
                p.setActivo(rs.getString("activo"));
            }
        } catch (Exception e) {
        }
        return null;
    }

    @Override
    public boolean agregar(Modelo.Localizaciones per) {
        String sql="insert into localizaciones(id, localizacion, activo) values('"+per.getId()+"','"+per.getLocalizacion()+"','"+per.getActivo()+"')";
        try {
            con =cn.getConnection();
            ps=con.prepareStatement(sql);
            ps.executeUpdate();
        } catch (Exception e) {
        }
        return false;
    }

    @Override
    public boolean editar(Modelo.Localizaciones per) {
        String sql="update localizaciones set localizacion='"+per.getLocalizacion()+"','"+per.getActivo()+"'where id="+per.getId();
        try {
            con =cn.getConnection();
            ps=con.prepareStatement(sql);
            ps.executeUpdate();
        } catch (Exception e) {
        }
        return false;
    }

    @Override
    public boolean eliminar(int id) {
        String sql="delete from localizacion where id="+id;
        try {
            con =cn.getConnection();
            ps=con.prepareStatement(sql);
            ps.executeUpdate();
        } catch (Exception e) {
        }
        return false;
    }

    private void setId(String string) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void setLocalizacion(String string) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void setActivo(String string) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
}
