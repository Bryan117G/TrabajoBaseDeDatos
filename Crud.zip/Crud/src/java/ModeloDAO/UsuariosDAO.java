
package ModeloDAO;

import Config.Conexion;
import Interfaces.CRUDUsuarios;
import Modelo.Cargos;
import Modelo.Usuarios;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import static java.util.Collections.list;

/**
 *
 * @author bryan
 */
public class UsuariosDAO implements CRUDUsuarios{
    Conexion cn=new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    UsuariosDAO p=new UsuariosDAO();
    
    @Override
    public List listar() {
        ArrayList<UsuariosDAO>list=new ArrayList<>();
        String sql="select * from Usuarios";
        try {
            con=cn.getConnection();
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            while(rs.next()){
                UsuariosDAO per=new UsuariosDAO();
                per.setId(rs.getString("id"));
                per.setNombres(rs.getString("nombres"));
                per.setApellidos(rs.getString("apellidos"));
                per.setIdentificacion(rs.getString("identificacion"));
                per.setLocalizacion_id(rs.getString("localizacion_id"));
                per.setCargo_id(rs.getString("cargo_id"));
                per.setActivo(rs.getString("activo"));
                list.add(per);
            }
        } catch (Exception e) {
        }
        return list;
    }

    @Override
    public Usuarios list(int id) {
        String sql="select * from usuarios where id="+id;
        try {
            con=cn.getConnection();
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            while(rs.next()){
                p.setId(rs.getString("id"));
                p.setNombres(rs.getString("nombres"));
                p.setApellidos(rs.getString("apellidos"));
                p.setIdentificacion(rs.getString("identificacion"));
                p.setLocalizacion_id(rs.getString("localizacion_id"));
                p.setCargo_id(rs.getString("cargo_id"));
                p.setActivo(rs.getString("activo"));
            }
        } catch (Exception e) {
        }
        return null;
    }

    public boolean agregarUsuarios(Modelo.Usuarios per) {
        String sql="insert into usuarios(id, nombres,apellidos, identificacion, localizacion_id,cargo_id, activo) values('"+per.getId()+"','"+per.getNombres()+"','"+per.getApellidos()+"','"+per.getIdentificacion()+"','"+per.getLocalizacion_id()+"','"+per.getCargo_id()+"','"+per.getActivo()+"')";
        try {
            con =cn.getConnection();
            ps=con.prepareStatement(sql);
            ps.executeUpdate();
        } catch (Exception e) {
        }
        return false;
    }

    @Override
    public boolean editarUsuarios(Modelo.Usuarios per) {
        String sql="update localizaciones set localizacion='"+per.getNombres()+"','"+per.getApellidos()+"','"+per.getIdentificacion()+"','"+per.getLocalizacion_id()+"','"+per.getCargo_id()+per.getActivo()+"'where id="+per.getId();
        try {
            con =cn.getConnection();
            ps=con.prepareStatement(sql);
            ps.executeUpdate();
        } catch (Exception e) {
        }
        return false;
    }

    @Override
    public boolean eliminarUsuarios(int id) {
        String sql="delete from localizacion where id="+id;
        try {
            con =cn.getConnection();
            ps=con.prepareStatement(sql);
            ps.executeUpdate();
        } catch (Exception e) {
        }
        return false;
    }

    private void setId(String string) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void setNombres(String string) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void setApellidos(String string) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void setIdentificacion(String string) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void setLocalizacion_id(String string) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void setCargo_id(String string) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void setActivo(String string) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }


    
}
