
package ModeloDAO;

import Config.Conexion;
import Interfaces.CRUDCargo;
import Modelo.Cargos;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import static java.util.Collections.list;

/**
 *
 * @author bryan
 */
public class CargosDAO implements CRUDCargo{
    Conexion cn=new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    CargosDAO p=new CargosDAO();
    
    @Override
    public List listar() {
        ArrayList<CargosDAO>list=new ArrayList<>();
        String sql="select * from cargos";
        try {
            con=cn.getConnection();
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            while(rs.next()){
                CargosDAO per=new CargosDAO();
                per.setId(rs.getString("id"));
                per.setCargo(rs.getString("cargo"));
                per.setActivo(rs.getString("activo"));
                list.add(per);
            }
        } catch (Exception e) {
        }
        return list;
    }

    @Override
    public Cargos list(int id) {
        String sql="select * from cargos where id="+id;
        try {
            con=cn.getConnection();
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            while(rs.next()){
                p.setId(rs.getString("id"));
                p.setCargo(rs.getString("cargos"));
                p.setActivo(rs.getString("activo"));
            }
        } catch (Exception e) {
        }
        return null;
    }

    public boolean agregarCargo(Modelo.Cargos per) {
        String sql="insert into cargos(id, cargo, activo) values('"+per.getId()+"','"+per.getCargo()+"','"+per.getActivo()+"')";
        try {
            con =cn.getConnection();
            ps=con.prepareStatement(sql);
            ps.executeUpdate();
        } catch (Exception e) {
        }
        return false;
    }

    @Override
    public boolean editarCargo(Modelo.Cargos per) {
        String sql="update localizaciones set localizacion='"+per.getCargo()+"','"+per.getActivo()+"'where id="+per.getId();
        try {
            con =cn.getConnection();
            ps=con.prepareStatement(sql);
            ps.executeUpdate();
        } catch (Exception e) {
        }
        return false;
    }

    @Override
    public boolean eliminarCargo(int id) {
        String sql="delete from localizacion where id="+id;
        try {
            con =cn.getConnection();
            ps=con.prepareStatement(sql);
            ps.executeUpdate();
        } catch (Exception e) {
        }
        return false;
    }

    private void setId(String string) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void setCargo(String string) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void setActivo(String string) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
}
