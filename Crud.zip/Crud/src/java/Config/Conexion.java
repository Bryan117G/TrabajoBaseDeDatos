
package Config;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author bryan
 */
public class Conexion {
    Connection con;
    public Conexion(){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/trabajo","root","");            
        } catch (Exception e) {
            System.err.println("Error"+e);
        }
    }
    public Connection getConnection(){
        return con;
    }
    
    public static void main(String[] args) {
        Conexion con = new Conexion();
    }
}